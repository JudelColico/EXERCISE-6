<!-- header.php -->
<?php
  header("Content-Type: text/html; charset=UTF-8");
  header("Cache-Control: no-cache, must-revalidate");
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Welcome Page</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <header>
  <div class="logo">
      <a href="index.php"> <img src="images/ELMO.png" alt="burning elmo with a cookie hair"> </a>
  </div>
    <nav>
      <ul>
        <li><a href="team.php">About Team</a></li>
      </ul>
    </nav>
  </header>